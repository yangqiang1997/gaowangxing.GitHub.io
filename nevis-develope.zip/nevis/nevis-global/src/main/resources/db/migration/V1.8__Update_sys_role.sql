
UPDATE `sys_role` SET `role_type`='Admin' WHERE (`role_id`='7423fdab-e5c5-47ab-b0b4-9d8969aba531')