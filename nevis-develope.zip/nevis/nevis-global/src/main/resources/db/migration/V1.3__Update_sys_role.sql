ALTER TABLE `sys_role` ADD COLUMN `role_type` VARCHAR (50);
