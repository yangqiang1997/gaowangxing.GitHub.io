ALTER TABLE sys_user modify birthdate DATE DEFAULT NULL;
