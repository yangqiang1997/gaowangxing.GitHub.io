UPDATE  `sys_organization_type` SET `organization_type_name` = '部门'
, `organization_extension_info_table_name` ='department'
WHERE `organization_type_id` = 'f8b9e68a-cc73-409f-8293-32e0365a682d'