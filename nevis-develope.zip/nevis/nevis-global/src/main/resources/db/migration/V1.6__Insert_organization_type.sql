-- ----------------------------
-- Table structure for sys_code_table
-- ----------------------------
DROP TABLE IF EXISTS `sys_code_table`;

INSERT INTO `sys_organization_type` (`organization_type_id`, `organization_type_name`,`organization_extension_info_table_name`) VALUES ('d6e03a22-0046-4582-a201-816888fb3ece', '公司','company');
INSERT INTO `sys_organization_type` (`organization_type_id`, `organization_type_name`,`organization_extension_info_table_name`) VALUES ('f8b9e68a-cc73-409f-8293-32e0365a682d', '个人','person');