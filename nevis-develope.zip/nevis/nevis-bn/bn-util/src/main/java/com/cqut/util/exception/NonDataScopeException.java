package com.cqut.util.exception;

public class NonDataScopeException extends Exception {

    public NonDataScopeException(String message) {
        super(message);
    }
}
