package com.cqut.util.exception;

public class BusinessException extends Exception {

    public BusinessException(String msg) {
        super(msg);
    }
}
