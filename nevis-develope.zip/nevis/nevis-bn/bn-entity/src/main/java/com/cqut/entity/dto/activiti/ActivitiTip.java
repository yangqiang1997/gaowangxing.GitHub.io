package com.cqut.entity.dto.activiti;
/**
 * 杨强
 * 2018.4.16
 */
public class ActivitiTip {

    public static final String PROCESS_NON_EXIST = "流程实例不存在";
    public static final String START_INCOMPLETE_DATA = "启动流程数据不完整";
    public static final String PUSH_INCOMPLETE_DATA = "推动流程数据不完整";
    public static final String CANNOT_PUSH_PROCESS = "当前角色不能用户推动流程";
    public static final String TASK_HAS_BEEN_COMPLETED = "此任务已经被完成";
    public static final String COMPLETED_TASK_DEFAULT = "完成任务失败";
}
