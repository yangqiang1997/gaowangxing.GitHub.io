package com.cqut.entity.dto.group;

public interface Add {
}
