package com.cqut.entity.dto.activiti;

/**
 * 杨强
 * 2018.4.16
 */
public class ProcessRecordQueryDTO {
    /**
     * 流程实例id
     */
    private String processInstanceId;

    public String getProcessInstanceId() {
        return processInstanceId;
    }

    public void setProcessInstanceId(String processInstanceId) {
        this.processInstanceId = processInstanceId;
    }
}
